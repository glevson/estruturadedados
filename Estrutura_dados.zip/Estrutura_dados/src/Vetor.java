public class Vetor {
    private Aluno[] alunos = new Aluno[100];

    private int totalDealunos = 0;

    public void Adiciona (Aluno aluno){
        this.alunos[this.totalDealunos]= aluno;
        this.totalDealunos++;
    }

    public int getTotalDealunos(){
        return totalDealunos;
    }

    public void adicionaPosicao(int posicao, Aluno aluno){


    }

    public void Alunopega (int posicao){
        //implementar
    }

    public void remove(int posicao){
        //implementar
    }

    public  boolean contem(Aluno aluno){
        return true;
    }

    public int tamanho (){
        return this.totalDealunos;
    }

    public String toString() {
        return Arrays.toString(alunos);
    }

}
